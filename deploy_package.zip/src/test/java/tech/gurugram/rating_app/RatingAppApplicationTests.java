package tech.gurugram.rating_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
