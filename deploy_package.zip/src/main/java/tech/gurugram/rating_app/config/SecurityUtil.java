package tech.gurugram.rating_app.config;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collection;

/**
 * Utility class to get current user information from SecurityContext.
 * Assumes JWT authentication where:
 * - Authentication.getName() returns the user ID as a string
 * - Authorities contain role names (e.g., "SYSTEM_ADMIN", "STORE_OWNER", "USER")
 */
public class SecurityUtil {

    /**
     * Get the current user's ID from the security context.
     * Returns null if not authenticated or if the principal is not a valid user ID.
     */
    public static Long currentUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated() || "anonymousUser".equals(auth.getPrincipal())) {
            return null;
        }

        try {
            String name = auth.getName();
            return Long.parseLong(name);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /**
     * Check if the current user has SYSTEM_ADMIN role.
     */
    public static boolean isAdmin() {
        return hasRole("SYSTEM_ADMIN");
    }

    /**
     * Check if the current user has STORE_OWNER role.
     */
    public static boolean isStoreOwner() {
        return hasRole("STORE_OWNER");
    }

    /**
     * Check if the current user has USER role.
     */
    public static boolean isUser() {
        return hasRole("USER");
    }

    /**
     * Check if the current user has a specific role.
     */
    public static boolean hasRole(String roleName) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth == null || !auth.isAuthenticated()) {
            return false;
        }

        Collection<? extends GrantedAuthority> authorities = auth.getAuthorities();
        return authorities.stream()
                .anyMatch(a -> a.getAuthority().equals(roleName) ||
                        a.getAuthority().equals("ROLE_" + roleName));
    }
    public static Authentication getAuthentication() {
        return SecurityContextHolder.getContext().getAuthentication();
    }
}