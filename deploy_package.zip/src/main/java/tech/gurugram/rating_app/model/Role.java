package tech.gurugram.rating_app.model;

import jakarta.persistence.*;

@Entity
@Table(name = "role")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name; // e.g. SYSTEM_ADMIN, STORE_OWNER, USER

    public Role() {}

    public Role(String name) { this.name = name; }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}
/*
public enum Role {
    ROLE_ADMIN,
    ROLE_STORE_OWNER,
    ROLE_USER
}
*/