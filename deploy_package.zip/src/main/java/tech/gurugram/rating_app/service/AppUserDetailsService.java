// src/main/java/tech/gurugram/rating_app/service/AppUserDetailsService.java
package tech.gurugram.rating_app.service;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import tech.gurugram.rating_app.model.User;
import tech.gurugram.rating_app.repository.UserRepository;

import java.util.Collection;
import java.util.stream.Collectors;

@Service
public class AppUserDetailsService implements UserDetailsService {

    private final UserRepository repo;

    public AppUserDetailsService(UserRepository repo) {
        this.repo = repo;
    }

    @Override
    // --- FIX: The "username" parameter is treated as an email ---
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // --- FIX: Use findByEmail ---
        User u = repo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));

        // Create Spring Security User
        return new org.springframework.security.core.userdetails.User(
                u.getEmail(), // --- FIX: Use email as the "username" ---
                u.getPassword(),
                true, true, true, true,
                getAuthorities(u)
        );
    }

    private Collection<? extends GrantedAuthority> getAuthorities(User user) {
        return user.getRoles().stream()
                .map(role -> new SimpleGrantedAuthority("ROLE_" + role.getName()))
                .collect(Collectors.toList());
    }
}