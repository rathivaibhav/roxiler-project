// src/main/java/tech/gurugram/rating_app/service/StoreService.java
package tech.gurugram.rating_app.service;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import tech.gurugram.rating_app.dto.StoreListingDto;
import tech.gurugram.rating_app.model.Rating;
import tech.gurugram.rating_app.model.Store;
import tech.gurugram.rating_app.repository.RatingRepository;
import tech.gurugram.rating_app.repository.StoreRepository;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class StoreService {

    private final StoreRepository storeRepository;
    private final RatingRepository ratingRepository;

    public StoreService(StoreRepository storeRepository, RatingRepository ratingRepository) {
        this.storeRepository = storeRepository;
        this.ratingRepository = ratingRepository;
    }

    public List<StoreListingDto> getStoreListings(Long userId, String name, String address) {
        // 1. Build specification for filtering by name and/or address
        Specification<Store> spec = (root, q, cb) -> cb.conjunction();
        if (StringUtils.hasText(name)) {
            spec = spec.and((root, q, cb) ->
                    cb.like(cb.lower(root.get("name")), "%" + name.toLowerCase() + "%"));
        }
        if (StringUtils.hasText(address)) {
            spec = spec.and((root, q, cb) ->
                    cb.like(cb.lower(root.get("address")), "%" + address.toLowerCase() + "%"));
        }

        List<Store> stores = storeRepository.findAll(spec);

        // 2. Get the current user's ratings for all these stores in one query
        List<Long> storeIds = stores.stream().map(Store::getId).collect(Collectors.toList());
        Map<Long, Integer> userRatingsMap = ratingRepository.findByStoreIdInAndUserId(storeIds, userId)
                .stream()
                .collect(Collectors.toMap(r -> r.getStore().getId(), Rating::getScore));

        // 3. Convert to DTOs
        return stores.stream().map(store -> {
            StoreListingDto dto = new StoreListingDto();
            dto.setId(store.getId());
            dto.setName(store.getName());
            dto.setAddress(store.getAddress());
            dto.setEmail(store.getEmail());

            // 4. Get average rating
            Double avg = ratingRepository.getAverageRatingByStoreId(store.getId());
            dto.setOverallRating(avg != null ? (Math.round(avg * 100.0) / 100.0) : null);

            // 5. Get this user's rating
            dto.setUserSubmittedRating(userRatingsMap.get(store.getId()));

            return dto;
        }).collect(Collectors.toList());
    }
}