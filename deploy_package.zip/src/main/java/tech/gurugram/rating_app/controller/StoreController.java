// src/main/java/tech/gurugram/rating_app/controller/StoreController.java
package tech.gurugram.rating_app.controller;

import tech.gurugram.rating_app.config.SecurityUtil;
import tech.gurugram.rating_app.dto.StoreListingDto; // Import new DTO
import tech.gurugram.rating_app.service.StoreService; // Import new Service
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/stores")
@PreAuthorize("isAuthenticated()") // Only logged-in users can see stores
public class StoreController {

    // --- NEW: Use StoreService ---
    private final StoreService storeService;

    public StoreController(StoreService storeService) {
        this.storeService = storeService;
    }

    /**
     * This single endpoint fulfills all Normal User requirements:
     * - Lists stores
     * - Searches by Name and Address
     * - Returns Overall Rating
     * - Returns User's Submitted Rating
     */
    @GetMapping
    public ResponseEntity<?> listStores(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String address
    ) {
        Long userId = SecurityUtil.currentUserId();
        if (userId == null) {
            return ResponseEntity.status(401).body("User not authenticated");
        }

        List<StoreListingDto> stores = storeService.getStoreListings(userId, name, address);
        return ResponseEntity.ok(stores);
    }

    // ... (Your other POST, PUT, DELETE methods from before can stay if admins/owners use them) ...
}